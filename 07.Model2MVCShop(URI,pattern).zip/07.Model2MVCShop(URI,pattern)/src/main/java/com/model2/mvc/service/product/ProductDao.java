package com.model2.mvc.service.product;

import java.util.List;

import com.model2.mvc.common.Search;
import com.model2.mvc.service.domain.Product;

//==> ��ǰ�������� CRUD �߻�ȭ/ĸ��ȭ�� DAO Interface Definition
public interface ProductDao {

	// INSERT
	public void insertProduct(Product product) throws Exception;
	
	// SELECT ONE
	public Product findProduct(int prodNo) throws Exception;
	
	// UPDATE
	public void updateProduct(Product product) throws Exception;
	
	// DELETE
	public void deleteProduct(int prodNo) throws Exception;
	
	// SELECT LIST
	public List <Product> getProductList(Search search) throws Exception;
	
	// �Խ��� Page ó���� ���� ��üRow(totalCount)  return
	public int getTotalCount(Search search) throws Exception ;
	
}
